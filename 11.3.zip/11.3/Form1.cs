﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11._3
{
    public partial class robot :Form
    {
        public robot ()
        {
            InitializeComponent();
        }

        private void robot_Load (object sender, EventArgs e)
        {
        }

        private void button1_Click (object sender, EventArgs e)
        {
            try
            {

                if (checkBox1.Checked)
                {
                    Robot robot1 = new Robot();
                    Random rnd = new Random();
                    int a = rnd.Next(0, 100);
                    robot1.min(a);
                    robot1.kollife = Convert.ToInt32(textBox1.Text);
                    label1.Text = "Количестов жизней в начале игры " + Convert.ToString(robot1.kollife);
                }


                if (checkBox2.Checked)
                {
                    Robot robot2 = new Robot();
                    Random rnd = new Random();
                    int b = rnd.Next(0, 100);
                    robot2.min(b);
                    robot2.kollife = Convert.ToInt32(textBox2.Text);
                    label3.Text = "Количестов жизней в начале игры " + Convert.ToString(robot2.kollife);
                }

                if (checkBox4.Checked)
                {
                    Robot robot3 = new Robot();
                    Random rnd = new Random();
                    int c = rnd.Next(0, 100);
                    robot3.min(c);
                    robot3.kollife = Convert.ToInt32(textBox3.Text);
                    label5.Text = "Количестов жизней в начале игры " + Convert.ToString(robot3.kollife);
                }
            }
            catch { MessageBox.Show("неверный формат ввода"); }
        }
        private void button2_Click (object sender, EventArgs e)
        {
            try
            {
                if (checkBox1.Checked)
                {
                    Robot robot1 = new Robot();
                    Random rnd = new Random();
                    int a = rnd.Next(0, 100);
                    robot1.min(a);
                    robot1.kollife = Convert.ToInt32(textBox1.Text);
                    robot1.min(robot1.kollife);
                    robot1.kol(a, robot1.kollife);
                    label2.Text = "Количество жизней робота после игры " + Convert.ToString(robot1.getlife());
                }

                if (checkBox2.Checked)
                {
                    Robot robot2 = new Robot();
                    Random rnd = new Random();
                    int a = rnd.Next(0, 100);
                    robot2.min(a);
                    robot2.kollife = Convert.ToInt32(textBox2.Text);
                    robot2.min(robot2.kollife);
                    robot2.kol(a, robot2.kollife);
                    label4.Text = "Количество жизней робота после игры " + Convert.ToString(robot2.getlife());
                }

                if (checkBox4.Checked)
                {
                    Robot robot3 = new Robot();
                    Random rnd = new Random();
                    int a = rnd.Next(0, 100);
                    robot3.min(a);
                    robot3.kollife = Convert.ToInt32(textBox3.Text);
                    robot3.min(robot3.kollife);
                    robot3.kol(a, robot3.kollife);
                    label6.Text = "Количество жизней робота после игры " + Convert.ToString(robot3.getlife());
                }
            }
            catch { MessageBox.Show("неверный формат ввода"); }
        }


        private void checkbox1 (object sender, EventArgs e)
        {
            RadioButton radioButton1 = (RadioButton) sender;
            if (radioButton1.Checked.Equals(true))
            {
            }
        }
        private void checkbox2 (object sender, EventArgs e)
        {
            RadioButton radioButton1 = (RadioButton) sender;
            if (radioButton1.Checked.Equals(true))
            {
            }
        }
        private void checkbox3 (object sender, EventArgs e)
        {
            RadioButton radioButton1 = (RadioButton) sender;
            if (radioButton1.Checked.Equals(true))
            {
            }
        }
    }
}
