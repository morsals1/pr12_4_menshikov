﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._3
{
    class Robot
    {
        public int kollife;
        public int getlife () 
        {
            return kollife;
        }

        public void min(int a) 
        {
            Random rn1 = new Random();
            kollife = a;
            kollife = rn1.Next(a*70/100);
        }
        public void kol(int a, int k) 
        {
            if (k == a / 2) 
            {
                kollife += 30;
            }
            else if(k == a*0.7)
            {
                kollife += 20;
            }
        }
    }
}
