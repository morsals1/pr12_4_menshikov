﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prak12_6v
{
    class Buyer
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public double Wallet { get; set; }
        public int Mood { get; set; } = 10;
        public double itog {  get; set; }

        public void Set_itog() 
        {
            itog = Price*Quantity;
            if(Wallet >= itog) 
            {
                Wallet -= itog;
                Mood += (int)(0.5 * itog);
            }
            else 
            {
                double itog_m = itog - Wallet;
                Mood -= (int)itog_m;
            }
        }
        public string info_itog() 
        {
            return $" {Wallet} - денег; {Mood} - настроение";
        }
        public string Info() 
        {
            return $" Продукт: {Name};\n Цена: {Price} рублей;\n Количество: {Quantity} штук(а); ";
        }

    }
}
