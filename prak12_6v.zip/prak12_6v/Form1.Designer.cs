﻿
namespace prak12_6v
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            p_name = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            price = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            quantity = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            wallet = new System.Windows.Forms.TextBox();
            listBox1 = new System.Windows.Forms.ListBox();
            buy = new System.Windows.Forms.Button();
            clear_all = new System.Windows.Forms.Button();
            clear = new System.Windows.Forms.Button();
            label6 = new System.Windows.Forms.Label();
            itog = new System.Windows.Forms.TextBox();
            add = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // p_name
            // 
            p_name.Location = new System.Drawing.Point(12, 37);
            p_name.Name = "p_name";
            p_name.Size = new System.Drawing.Size(100, 23);
            p_name.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(12, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(252, 25);
            label1.TabIndex = 1;
            label1.Text = "Введите название продукта";
            // 
            // price
            // 
            price.Location = new System.Drawing.Point(12, 110);
            price.Name = "price";
            price.Size = new System.Drawing.Size(100, 23);
            price.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(12, 82);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(128, 25);
            label2.TabIndex = 3;
            label2.Text = "Введите цену";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(12, 159);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(187, 25);
            label3.TabIndex = 4;
            label3.Text = "Введите количество";
            // 
            // quantity
            // 
            quantity.Location = new System.Drawing.Point(12, 187);
            quantity.Name = "quantity";
            quantity.Size = new System.Drawing.Size(100, 23);
            quantity.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(314, 9);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(213, 25);
            label4.TabIndex = 7;
            label4.Text = "Информацияо покупке";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(12, 240);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(86, 25);
            label5.TabIndex = 9;
            label5.Text = "кошелек";
            // 
            // wallet
            // 
            wallet.Location = new System.Drawing.Point(12, 268);
            wallet.Name = "wallet";
            wallet.Size = new System.Drawing.Size(100, 23);
            wallet.TabIndex = 10;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new System.Drawing.Point(314, 43);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(333, 319);
            listBox1.TabIndex = 11;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // buy
            // 
            buy.Location = new System.Drawing.Point(653, 43);
            buy.Name = "buy";
            buy.Size = new System.Drawing.Size(135, 35);
            buy.TabIndex = 12;
            buy.Text = "Купить";
            buy.UseVisualStyleBackColor = true;
            buy.Click += buy_Click;
            // 
            // clear_all
            // 
            clear_all.Location = new System.Drawing.Point(653, 327);
            clear_all.Name = "clear_all";
            clear_all.Size = new System.Drawing.Size(135, 35);
            clear_all.TabIndex = 13;
            clear_all.Text = "Сбросить все";
            clear_all.UseVisualStyleBackColor = true;
            clear_all.Click += clear_Click;
            // 
            // clear
            // 
            clear.Location = new System.Drawing.Point(653, 268);
            clear.Name = "clear";
            clear.Size = new System.Drawing.Size(135, 35);
            clear.TabIndex = 14;
            clear.Text = "Сбросить поля ввода";
            clear.UseVisualStyleBackColor = true;
            clear.Click += clear_Click_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(314, 376);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(63, 25);
            label6.TabIndex = 16;
            label6.Text = "Итого";
            // 
            // itog
            // 
            itog.Location = new System.Drawing.Point(314, 404);
            itog.Name = "itog";
            itog.Size = new System.Drawing.Size(333, 23);
            itog.TabIndex = 17;
            // 
            // add
            // 
            add.Location = new System.Drawing.Point(653, 98);
            add.Name = "add";
            add.Size = new System.Drawing.Size(135, 35);
            add.TabIndex = 18;
            add.Text = "добавить";
            add.UseVisualStyleBackColor = true;
            add.Click += add_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(add);
            Controls.Add(itog);
            Controls.Add(label6);
            Controls.Add(clear);
            Controls.Add(clear_all);
            Controls.Add(buy);
            Controls.Add(listBox1);
            Controls.Add(wallet);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(quantity);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(price);
            Controls.Add(label1);
            Controls.Add(p_name);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox p_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox price;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox wallet;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button buy;
        private System.Windows.Forms.Button clear_all;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox itog;
        private System.Windows.Forms.Button add;
    }
}

