﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prak12_6v
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void buy_Click(object sender, EventArgs e)
        {
            try {

                Buyer buyer = new Buyer();
                buyer.Name = p_name.Text;
                buyer.Price = Convert.ToDouble(price.Text);
                buyer.Quantity = Convert.ToInt32(quantity.Text);
                buyer.Wallet = Convert.ToDouble(wallet.Text);
                for(int i=0; i<listBox1.Items.Count; i++) 
                {
                    buyer.Set_itog();
                }
                itog.Text = buyer.info_itog();
            }
            catch (Exception ex) { MessageBox.Show("НЕВЕРНЫЙ ВВОД"); }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            p_name.Clear();
            price.Clear();
            quantity.Clear();
            wallet.Clear();
            itog.Clear();
        }

        private void clear_Click_1(object sender, EventArgs e)
        {
            p_name.Clear();
            price.Clear();
            quantity.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void add_Click(object sender, EventArgs e)
        {
            try {

                Buyer buyer = new Buyer();
                buyer.Name = p_name.Text;
                buyer.Price = Convert.ToDouble(price.Text);
                buyer.Quantity = Convert.ToInt32(quantity.Text);
                //info
                listBox1.Items.Add(buyer.Info());
            }
            catch (Exception ex) { MessageBox.Show("НЕВЕРНЫЙ ВВОД"); }
        }
    }
}
